#!/usr/bin/env python
#-*- coding:utf-8 -*-

import os
import re
import sys
import mmap

_pDiffHead = re.compile(r'^@@\s[-]([\d]+)([,\d]*)\s[+]([\d]+)([,\d]*)\s@@.*')
(LINE_MODE, FUNCTION_MODE) = range(2)


def git_launch(cmd):
	p = os.popen(cmd, 'r')
	lines = []
	while True:
		line = p.readline()
		if not line:
			break
		lines.append(line.rstrip())
	return lines


class BugTeller:

	def __init__(self, mode, line_offset):
		self.mode = mode
		self.function_name = None
		self.line_offset = line_offset

	def is_fixing_patch(self, bug_commit, file_name, line_no, commit):
		if self.mode == LINE_MODE:
			return self.__check_by_line(bug_commit, file_name, line_no, commit)
		else:
			return self.__check_by_function(bug_commit, file_name, line_no, commit)

	def __check_by_line(self, bug_commit, file_name, line_no, commit):
		cmd = 'git diff -U0 --minimal %s %s %s' % (bug_commit, commit, file_name)
		diffs = git_launch(cmd)
		fixed = False
		for diff in diffs:
			if diff[0] == '@':
				m = _pDiffHead.match(diff)
				if m:
					mod_line = int(m.group(1))
					mod_amount = m.group(2)
					if not mod_amount:
						mod_amount = 1
					elif mod_amount[0] == ',':
						mod_amount = int(mod_amount[1:])
					else:
						mod_amount = 0
					mod_line_to = mod_line + mod_amount

					line_from = line_no - self.line_offset
					line_to = line_no + self.line_offset
					if (line_from <= mod_line <= line_to) or (line_from <= mod_line_to <= line_to)\
						and \
						(mod_line <= line_from <= mod_line_to) or (mod_line <= line_to <= mod_line_to):
						fixed = True
						break
		return fixed

	def __removeLine(self, file_name, line_no):
		f = os.open(file_name, os.O_RDWR)
		m = mmap.mmap(f, 0)
		p = 0
		for i in range(line_no - 1):
			p = m.find('\n', p) + 1
		q = m.find('\n', p)
		m[p:q] = ' ' * (q - p)
		os.close(f)

	def __find_function_name_from_diffs(self, diffs, line_no):
		res = "-"
		for line in diffs:
			if line[0] != '@':
				continue

			line_parts = line.split(' @@ ')
			if len(line_parts) < 2:
				continue

			m = _pDiffHead.match(line)
			if not m:
				continue

			mod_line = int(m.group(3))
			mod_amount = m.group(4)
			if not mod_amount:
				mod_amount = 1
			elif mod_amount[0] == ',':
				mod_amount = int(mod_amount[1:])
			else:
				mod_amount = 0
			mod_line_to = mod_line + mod_amount

			if mod_line <= line_no <= mod_line_to:
				res = line_parts[1]
		return res

	def __check_by_function(self, bug_commit, file_name, line_no, commit):
		# We should find the function contains the line
		if not self.function_name:
			# The first commit to introduce the bug
			cmd = 'git blame -l -L%d,+%d %s -- %s' % (line_no, 1, bug_commit, file_name)
			blame = git_launch(cmd)
			if not blame or len(blame) < 1:
				# Should not be here
				return False
			bug_first_commit = blame[0].split(' ')[0]

			# Here search for the function name of the bug line
			if bug_first_commit[0] == '^':
				print "[BUG_TELLER] This will take a little time... Please do not terminate the process..."
				print "[BUG_TELLER] Begin..."
				# 2. Back up the file
				print "[BUG_TELLER]    Back up file %s..." % file_name
				os.system("cp %s %s.bak" % (file_name, file_name))
				# 3. Reset the file to the bug-discovered version to stage
				print "[BUG_TELLER]    Reset file to stage..."
				cmd = "git reset %s %s" % (bug_commit, file_name)
				git_launch(cmd)
				# 4. Check out the file in stage to workspace
				print "[BUG_TELLER]    Check out file to workspace..."
				cmd = "git checkout -- %s" % file_name
				git_launch(cmd)
				# 5. Remove the line of the bug
				print "[BUG_TELLER]    Remove line %d from file..." % line_no
				self.__removeLine(file_name, line_no)
				# 6. Compare the file with that before removing the line
				# to get the function of the
				print "[BUG_TELLER]    Compare to find the function name..."
				cmd = 'git diff -U0 %s' % file_name
				diffs = git_launch(cmd)
				# 6.1. See what the function name is
				self.function_name = self.__find_function_name_from_diffs(diffs, line_no)
				# 7. Recover the file from HEAD
				print "[BUG_TELLER]    Function name: %s..." % self.function_name
				print "[BUG_TELLER]    Recovering file..."
				cmd = 'git reset HEAD %s' % file_name
				git_launch(cmd)
				cmd = 'git checkout -- %s' % file_name
				git_launch(cmd)

				# 8. OK then recover the file
				os.system("rm %s.bak" % file_name)
				print "[BUG_TELLER] Done..."
				return False
			else:
				bug_first_commit_parent = bug_first_commit + '^'
				# Compare the commit before the bug-first commit with the bug-discovered commit
				cmd = 'git diff -U0 %s %s %s' % (bug_first_commit_parent, bug_commit, file_name)
				diffs = git_launch(cmd)
				self.function_name = self.__find_function_name_from_diffs(diffs, line_no)


			if self.function_name == '-':
				print '[BUG_TELLER] No function name was found.'
				return False
			else:
				print '[BUG_TELLER] Function is "%s" ' % self.function_name


		# Then iterate
		cmd = 'git diff -U0 --minimal %s %s %s' % (bug_commit, commit, file_name)
		diffs = git_launch(cmd)
		fixed = False
		for diff in diffs:
			if diff[0] != '@':
				continue
			line_parts = diff.split(' @@ ')
			if len(line_parts) < 2:
				continue
			object_function_name = line_parts[1]
			if object_function_name == self.function_name:
				fixed = True
				break
		return fixed

	def go(self, file_name, release_date, version_name, line_no, file_out):
		# Clear
		i = os.system('clear')

		# never changed since created
		if not os.path.isfile(file_name):
			print "[BUG_TELLER] File already removed."
			# TODO
			return

		# Get all the logs of the file
		print '[BUG_TELLER] Getting the commits of the file...'
		cmd = 'git log --since="%s" --reverse --pretty=format:"%%H" %s' % (release_date, file_name)
		commits = git_launch(cmd)
		print '[BUG_TELLER] %d commit(s) found.' % (len(commits))

		# The commit that has the bug
		print '[BUG_TELLER] Checking the commit of version %s' % version_name
		cmd = 'git tag -v v%s' % (version_name[6:])
		print cmd
		bug_commit = git_launch(cmd)[0][7:]
		print '[BUG_TELLER] Version %s responds to commit %s' % (version_name, bug_commit)

		if self.mode == FUNCTION_MODE:
			self.function_name = None

		# Scan the commit list to find which commit relates to this
		patch_commits = []
		for commit in commits:
			if self.is_fixing_patch(bug_commit, file_name, line_no, commit):
				patch_commits.append(commit)

		for patch_commit in patch_commits:
			print '[BUG_TELLER] PATCH COMMIT: %s' % patch_commit
			cmd = 'git diff -U0 --minimal %s %s %s' % (bug_commit, patch_commit, file_name)
			diffs = git_launch(cmd)
			for diff in diffs:
				file_out.write(diff)
				file_out.write('\n')


def main():
	try:
		f = open('README')
		if f.readline().find('Linux kernel') == -1:
			raise
		f.close()
	except:
		print 'Error: must run in linux kernel tree'
		exit(-1)

	fo = open(sys.argv[1], 'w')
	file_name = sys.argv[2]
	release_date = sys.argv[3]
	version_name = sys.argv[4]
	line_no = (int)(sys.argv[5])

	bug_teller = BugTeller(FUNCTION_MODE, 1)
	bug_teller.go(file_name, release_date, version_name, line_no, fo)


if __name__ == '__main__':
	main()


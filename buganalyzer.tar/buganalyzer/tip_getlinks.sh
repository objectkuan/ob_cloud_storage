#!/bin/bash

[[ -d $1 ]] || {
  echo 'usage: ./tip_getlinks.sh [git path]'
  exit 1
}

PATTERN="BugLink:"
cd $1
git log|grep -e 'commit [a-f0-9]\{40\}' -e $PATTERN|grep -B 1 -e $PATTERN| (
  while read -r a b; do
    [[ "$a" =~ 'commit' ]] && {
      read -r c link
      [[ "$link" == http* ]] && echo "$b" "$link"
    }
  done
)

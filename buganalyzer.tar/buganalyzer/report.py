#!/usr/bin/env python
#-*- coding:utf-8 -*-

import re, sys, os
import rfc822, datetime
import subprocess
from logparser import LogPatchSplitter
from patterns import patterns
from dateutil import parser

def main():
  #f = open(sys.argv[1])
  f = sys.stdin
  while True:
    line = f.readline()
    if not line: break
    t = line.split(' ')
    if len(t)<3:
      continue
    st = parser.parse(t[1])
    en = datetime.datetime(1990,1,1)
    for i in xrange(3,len(t),2):
      dt = parser.parse(t[i])
      if dt > en:
        en = dt
    if st>=en:
      print t[0], str(st.date()), str(dt.date()), str((st-en).days)
  #f.close()

if __name__ == '__main__':
  main()

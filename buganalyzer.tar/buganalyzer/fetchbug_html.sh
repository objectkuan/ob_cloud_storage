#!/bin/bash

[[ $# -ne 2 ]] && {
  echo "usage: ./fetchbug_html.sh [in] [out dir]"
  exit 1
}

mkdir "$2" &>/dev/null
[[ -f "$1" ]] || exit
OUTDIR="$2"

task()
{
  echo "$1"
  while read -r id link
  do
    echo "$link"
    curl -L "$link"  2>/dev/null 1>"$OUTDIR"/"$id".html 
  done < "$1"
  echo "$1" done
}


PROC=8
LINES=$(wc -l $1|awk '{print $1}')
PER_PROC=$(expr $LINES / $PROC )
echo "Total: $LINES, Per: $PER_PROC"
split -l $PER_PROC $1 "$2"/.task-
for f in "$2"/.task-*; do
  task "$f" &
done

wait

clear all;
log = importdata('report.out');
hist(log.data,round((max(log.data)-min(log.data))/30));
xlabel('how long to be fixed/days')
ylabel('bugs')
fprintf('Total: %d, Mean: %.2f days, median: %.2f days\n', length(log.data), ...
    mean(log.data), median(log.data));


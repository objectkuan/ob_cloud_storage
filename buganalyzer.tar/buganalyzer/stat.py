#!/usr/bin/env python
import sys, re, os
f = sys.stdin
l = []
while True:
  line = f.readline()
  if not line: break
  t = line.split(' ')
  l.append(int(t[3]))

s = 0.0
l.sort()
for x in l:
  s += x
  
print len(l), 'Avg:', s/len(l), ' ,median:', l[len(l)/2]

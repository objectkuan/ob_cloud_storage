#!/usr/bin/env python
#-*- coding:utf-8 -*-

import re, sys, os
import rfc822, datetime
import subprocess
from logparser import LogPatchSplitter
from patterns import patterns

#LINUX_SRC='/home/chenyh/os/linux'

#OPTION = {'useblame':False}
OPTION = {'useblame':True}

_pFixBug = re.compile('\\b(fix)|(fixes)|(resolve)|(a bug)|(bugs)|(reverts)\\b')
_pShortID = re.compile('\\b[0-9a-f]{7}\\b')
_pLongID = re.compile('\\b[0-9a-f]{40}\\b')

def contentHasBugInfo(content):
    if _pFixBug.search(content) and (_pShortID.search(content) or _pLongID.search(content)):
      return True
    return False
  

class Commit:
  def __init__(self, sl):
    self.commit = ''
    self.reportedby = ()
    self.fixedby = ('','')
    self.bugsource = set()
    self.date = None
    self.content = ''
    self.sourceline = sl
    self.contenthasbug = False

  def __str__(self):
    ret = ''
    ret += 'Commit: ' + self.commit + '\n'
    ret += 'Date: ' + str(self.date) + '\n'
    ret += 'Reported: ' + str(self.reportedby) + '\n'
    ret += 'Fixed: ' + str(self.fixedby) + '\n'
    ret += 'Source: ' + str(self.bugsource) + '\n'
#    ret += 'Content: ' + self.content + '\n'
    return ret

  def __searchBugInGit(self):
    if not OPTION['useblame']:
      return
    p = git_patch(self.commit)
    self.diffs = parseDiff(p)
    for fn in self.diffs:
      #print fn
      for x in self.diffs[fn]:
        lines = git_blame(x[0],x[1],self.commit,fn)
        for l in lines:
          cid = l.split(' ')[0]
          if cid not in self.bugsource:
            ll = git_lauch('git log -n 1 %s'%(cid))
            b = parsePatch(ll, False)
            if b:
              self.bugsource.add((cid,b.date))

  def getsource(self):
    if not self.contenthasbug:
      self.__searchBugInGit()
    else:
      cids = _pLongID.findall(self.content)
      if not cids:
        cids += _pShortID.findall(self.content)
      if len(cids)>0:
        for x in cids:
          ll = git_lauch('git log -n 1 %s'%(x))
          b = parsePatch(ll, False)
          if b:
            self.bugsource.add((b.commit,b.date))
      #fall back
      if len(self.bugsource)==0:
        self.__searchBugInGit()
    print self


def git_lauch(cmd):
  p = os.popen(cmd, 'r')
  lines = []
  while True:
    line = p.readline()
    if not line:
      break
    lines.append(line.rstrip())
  return lines


def git_patch(cid):
  if not cid:
    raise Error('Empty cid')
  cmd = 'git diff -U0 %s^ %s '%(cid,cid)
  return git_lauch(cmd)

def git_blame(line,lc,cid,fn):
  if not cid:
    raise Error('Empty cid')
  _lc = int(lc)
  if _lc<=0:
    _lc = 1
  cmd = 'git blame -l -L%d,+%d %s^ -- %s' % (int(line),_lc,cid,fn)
  return git_lauch(cmd)
  

def parseDiffline(m):
  g1 = m.group(1)
  g2 = m.group(2)
  if g1.find(',')==-1:
    g1 += ',0'
  if g2.find(',')==-1:
    g2 += ',0'
  t1 = g1.split(',')
  t2 = g2.split(',')
  return (t1[0],t1[1],t2[0],t2[1])
  

def parseDiff(lines):
  diffs = {}
  lst = []
  curfn = ''
  nlcnt = 0
  for l in lines:
    nlcnt += 1
    nl = ''
    if nlcnt < len(lines):
      nl = lines[nlcnt]
    m = patterns['diff'].match(l)
    if m:
      fa = m.group(1).replace('a/', '')
      fb = m.group(2).replace('b/', '')
#no support for adding/deleting files
      if fa!=fb or not nl.startswith('index'):
#TODO
        curfn = ''
        continue
      if curfn and len(lst)!=0:
        diffs[curfn] = lst
      lst = []
      curfn = fa
      continue
    if not curfn:
      continue
    #we use diff -U0
    m = patterns['diff-head'].match(l)
    if m:
      #a modification or deletion (bug fix)
      # how to handle adding missing code
      #if nl.startswith('-'):
      lst.append(parseDiffline(m))
      continue
  if curfn and len(lst)!=0:
    diffs[curfn] = lst
  return diffs

stat = 0
bugs = []
#commits = {}
def parsePatch(logp, judgeBug=True):
  if len(logp)<1:
    return None
  m = patterns['commit'].match(logp[0])
  if not m:
    return None
  cid = m.group(1)
  b = Commit(logp)
  b.commit = cid
  #commits[cid] = b
  isbug = False
  ismerge = False
  content = ''
  for line in logp[1:]:
    m = patterns['merge'].match(line)
    if m:
      ismerge = True
      continue
    m = patterns['reported-by'].match(line)
    if m: 
      b.reportedby += (m.group(1), m.group(2))
      b.commit = cid
      isbug = True
      continue
    m = patterns['reported-and-tested-by'].match(line)
    if m: 
      b.reportedby += (m.group(1), m.group(2))
      b.commit = cid
      isbug = True
      continue
    m = patterns['date'].match(line)
    if m:
      dt = rfc822.parsedate(m.group(2))
      b.date = datetime.date(dt[0],dt[1],dt[2])
      continue
    m = patterns['author'].match (line)
    if m:
      b.fixedby = (m.group(1), m.group(2))
      continue
    if len(line)>4 and line[0:2] == '  ':
      content += ' '+ line.strip() +' '
  b.content = content
# no merge
  if ismerge:
    return b
# commit log containing specific string 
# it is also a bug fixing
  if judgeBug:
    #if __pFixBug.search(content):
    #  isbug = True
    if isbug and contentHasBugInfo(content):
      b.contenthasbug = True
      isbug = True
    if not OPTION['useblame']:
      isbug = b.contenthasbug
    if isbug:
      bugs.append(b)
  return b


def main():
    #os.chdir(LINUX_SRC)
    try:
      f = open('README')
      if f.readline().find('Linux kernel')==-1:
        raise
      f.close()
    except:
      print 'Error: must run in linux kernel tree'
      exit(-1)
    patches = LogPatchSplitter(sys.stdin)
    for p in patches:
      parsePatch(p)
    print 'Bug Count:', len(bugs)
    #print bugs[10]
    #bugs[12].getsource()
    cnt = 0
    fo = open(sys.argv[1], 'w')
    for x in bugs:
      x.getsource()
      cnt+=1
      print cnt, len(bugs)
      fo.write(x.commit+' '+str(x.date))
      for y in x.bugsource:
        fo.write(' '+y[0]+' '+str(y[1]))
      fo.write('\n')
    fo.close()


if __name__ == '__main__':
  main()


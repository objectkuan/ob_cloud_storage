#!/usr/bin/env ruby

require 'yaml'

logs = Array.new

STDIN.each_line do |l|
	next if l =~ /-----.*/
	next if l =~ /ChangeLog-(.+)/
	l.strip!
	next if l.empty?
	unless l =~ /\.\s\(.+/
		nl = STDIN.gets.strip
		a = nl.split
		fail "line: #{nl}" unless a.shift=="."
		info = a.shift[1..-2].split "):("
		v = info.shift
		c = info.shift
		patchsize = a[-3..-1].map { |i| i.to_i } if a.length>=3
		hh = {:version => v.to_i, :component => c.split(','),
			:patchsize => patchsize }
		info.each { |e| e1, e2 = e.split ":"; hh[e1.intern] = e2 }
		logs.push({:log => l, :info => hh})
	end
end

#puts logs.length

#logs.each do |e|
#	l, hh = e
#	puts l
#	p hh
#end

puts YAML::dump(logs)

